import { MaterialModule } from '../material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {LoggedRoutingModule} from './logged-routing.module';
import { LoggedComponent } from './logged/logged.component';
import { ToolbarComponent } from './logged/toolbar/toolbar.component';
import { FotterComponent } from './fotter/fotter.component';
import { HomeComponent } from './logged/home/home.component';
import { TableFornecedorComponent } from './logged/home/table-fornecedor/table-fornecedor.component';
import { TableAtualizacoesComponent } from './logged/home/table-atualizacoes/table-atualizacoes.component';
import { ModalFornecedorComponent } from './logged/home/table-fornecedor/modal-fornecedor/modal-fornecedor.component';

@NgModule({
  declarations: [LoggedComponent, ToolbarComponent, FotterComponent, HomeComponent, TableFornecedorComponent, TableAtualizacoesComponent, ModalFornecedorComponent],
  imports: [
    CommonModule,
    MaterialModule,
    LoggedRoutingModule

  ],
  entryComponents: [
    ModalFornecedorComponent
  ]
})
export class ComponentsModule { }
