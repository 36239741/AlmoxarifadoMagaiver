import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalFornecedorComponent } from './modal-fornecedor.component';

describe('ModalFornecedorComponent', () => {
  let component: ModalFornecedorComponent;
  let fixture: ComponentFixture<ModalFornecedorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalFornecedorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalFornecedorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
