import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-table-atualizacoes',
  templateUrl: './table-atualizacoes.component.html',
  styleUrls: ['./table-atualizacoes.component.css']
})

export class TableAtualizacoesComponent implements OnInit {
  displayedColumns: string[] = ['data', 'item', 'nome','servico'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  constructor() { }

  ngOnInit() {
  }

}
export interface PeriodicElement {
  item: string;
  data: string;
  nome: string;
  servico: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {data: '20/02/2012', nome: 'Marcelo', item: "Martelo",servico: 'Retirada'},
  {data: '25/06/2019', nome: 'Vanessa', item: "Tesoura", servico: 'Entrada'},
  {data: '13/07/2018', nome: 'Leopoldo', item: "Alicate", servico: 'Entrada'},
  {data: '16/08/2018', nome: 'Ze', item: "Balde", servico: 'Retirada'},
  {data: '19/06/2018', nome: 'Lula', item: "Luva", servico: 'Retirada'},
  {data: '19/06/2018', nome: 'Lula', item: "Luva", servico: 'Entrada'},


];
