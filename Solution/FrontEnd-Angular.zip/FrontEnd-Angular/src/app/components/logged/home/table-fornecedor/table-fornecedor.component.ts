import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import {ModalFornecedorComponent} from 'src/app/components/logged/home/table-fornecedor/modal-fornecedor/modal-fornecedor.component'


@Component({
  selector: 'app-table-fornecedor',
  templateUrl: './table-fornecedor.component.html',
  styleUrls: ['./table-fornecedor.component.css']
})
export class TableFornecedorComponent implements OnInit {
  displayedColumns: string[] = ['data', 'item', 'fornecedor'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  constructor(public dialog: MatDialog) { }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }
  openDialog(row: PeriodicElement){

    this.dialog.open(ModalFornecedorComponent,{
      data:row
    } );

  }
}
export interface PeriodicElement {
  item: string;
  data: string;
  fornecedor: string;

}

const ELEMENT_DATA: PeriodicElement[] = [
  {data: '20/02/2012', item: 'Martelo', fornecedor: "MarteloSA"},
  {data: '25/06/2019', item: 'Tesoura', fornecedor: "TesouraSA"},
  {data: '13/07/2018', item: 'Alicate', fornecedor: "AlicateSA"},
  {data: '16/08/2018', item: 'Balde', fornecedor: "BaldeSA"},
  {data: '19/06/2018', item: 'Luva', fornecedor: "LuvaSA"},
  {data: '19/06/2018', item: 'Luva', fornecedor: "LuvaSA"},
  {data: '19/06/2018', item: 'Luva', fornecedor: "LuvaSA"},
  {data: '19/06/2018', item: 'Luva', fornecedor: "LuvaSA"},
  {data: '19/06/2018', item: 'Luva', fornecedor: "LuvaSA"},
  {data: '19/06/2018', item: 'Luva', fornecedor: "LuvaSA"},







];
