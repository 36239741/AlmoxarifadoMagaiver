import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableAtualizacoesComponent } from './table-atualizacoes.component';

describe('TableAtualizacoesComponent', () => {
  let component: TableAtualizacoesComponent;
  let fixture: ComponentFixture<TableAtualizacoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableAtualizacoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableAtualizacoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
