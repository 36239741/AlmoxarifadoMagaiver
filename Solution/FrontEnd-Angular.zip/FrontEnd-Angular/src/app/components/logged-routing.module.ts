import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoggedComponent } from './logged/logged.component';
import { HomeComponent } from './logged/home/home.component';

const routes: Routes = [
  {
    path: 'logado',
    component: LoggedComponent,
    children: [
      {
        path: 'home',
        component: HomeComponent
      }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoggedRoutingModule { }
